"""IRLS and SGPTL on diabetes and california_housing under an ELM transformation."""

import csv
import os
import sys
import warnings

sys.path.insert(0, os.path.join(os.path.dirname(__file__), os.pardir))
warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

import numpy as np
np.seterr(all="ignore")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.datasets import load_diabetes, fetch_california_housing
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Lasso as SkLasso

from src import irls, deflected_subgradient
from src.elm import ELM
from src.lasso_utils import f_lasso
from src.linear_solvers import solve_spd
from _plot_style import apply_style, style_axes, COLOR_IRLS, COLOR_DSM, SIZE_DOUBLE
apply_style()


SEED          = 42
H             = 200
LAMBDA        = 0.1
TEST_FRACTION = 0.2
IRLS_KMAX     = 100
DSM_IMAX      = 8000
DSM_DELTA0    = 0.1
DSM_RHO       = 0.7        # revised default (see Section 5.3.3)
DSM_RHO_OLD   = 0.9        # as-submitted default, kept for before/after table
DSM_DELTA0_OLD = 0.1       # as-submitted: delta0 = c * f_star (vs new: c * f(w_0))

FIG_DIR = os.path.join(os.path.dirname(__file__), os.pardir, "results", "figures")
TAB_DIR = os.path.join(os.path.dirname(__file__), os.pardir, "results", "tables")
os.makedirs(FIG_DIR, exist_ok=True)
os.makedirs(TAB_DIR, exist_ok=True)


def _split_scale(X, y, test_frac=TEST_FRACTION, seed=SEED):
    """Train/test split + standardisation fit on the train split only (no leakage)."""
    rng = np.random.RandomState(seed)
    perm = rng.permutation(len(y))
    n_test = int(test_frac * len(y))
    te, tr = perm[:n_test], perm[n_test:]
    X_tr, X_te = X[tr], X[te]
    y_tr, y_te = y[tr], y[te]

    scaler_x = StandardScaler().fit(X_tr)
    X_tr = scaler_x.transform(X_tr)
    X_te = scaler_x.transform(X_te)

    y_mean = float(y_tr.mean())
    y_std  = float(y_tr.std()) or 1.0
    y_tr = (y_tr - y_mean) / y_std
    y_te = (y_te - y_mean) / y_std
    return X_tr, X_te, y_tr, y_te


def load_dataset(name):
    if name == "diabetes":
        d = load_diabetes()
    elif name == "california":
        d = fetch_california_housing()
    else:
        raise ValueError(name)
    X = np.asarray(d.data, dtype=float)
    y = np.asarray(d.target, dtype=float)
    return _split_scale(X, y)


def build_hidden(X_tr_raw, X_te_raw, d_in, H=H, seed=SEED):
    """Apply the ELM projection to both splits using the same fixed W_1."""
    elm = ELM(d=d_in, p=H, activation="sigmoid", lam=LAMBDA, random_state=seed)
    return elm.transform(X_tr_raw), elm.transform(X_te_raw)


def reference_solution(X, y, lam):
    """sklearn coordinate descent reference at moderate tolerance.

    We use tol = 1e-4 with max_iter = 500 because (i) sklearn does not
    converge on either ELM-transformed instance even at 1e-12, and (ii)
    IRLS reaches f-values well below sklearn's plateau within 100 iter
    in any case --- so we use sklearn only as a third-party sanity check
    and let IRLS' final f provide the empirical reference for the
    gap-to-f^* visualisation in run_one()."""
    M = X.shape[0]
    sk = SkLasso(alpha=lam / M, fit_intercept=False,
                 max_iter=300, tol=1e-3)
    sk.fit(X, y)
    w_star = sk.coef_
    f_star = f_lasso(X, y, w_star, lam)
    return w_star, f_star


def ols_warm_start(X, y):
    """Cholesky-based (X^T X + eps I)^{-1} X^T y."""
    return solve_spd(X.T @ X + 1e-10 * np.eye(X.shape[1]),
                     X.T @ y, method="cholesky")


def _mse(y_true, y_pred):
    return float(np.mean((y_true - y_pred) ** 2))


def _sparsity(w, tol=1e-6):
    return float(np.mean(np.abs(w) < tol))


SPARSITY_TOLS = (1e-6, 1e-3)


def run_one(name):
    print(f"\n{'='*60}\nDataset: {name}\n{'='*60}")
    X_tr_raw, X_te_raw, y_tr, y_te = load_dataset(name)
    d_in = X_tr_raw.shape[1]
    M = X_tr_raw.shape[0]
    print(f"  n_train={M}, n_test={X_te_raw.shape[0]}, d={d_in}, H={H}")

    X_tr, X_te = build_hidden(X_tr_raw, X_te_raw, d_in)
    print(f"  hidden activations: shape={X_tr.shape}, "
          f"cond(X^T X) ≈ {np.linalg.cond(X_tr.T @ X_tr):.2e}")

    # sklearn CD does not converge on the California ELM in a reasonable budget
    # (M=16512, H=200, cond ~ 2.8e6); skip it there and use IRLS as the baseline.
    if name == "california":
        print("  sklearn skipped on this dataset; using OLS f as placeholder.")
        f_star = float(f_lasso(X_tr, y_tr, ols_warm_start(X_tr, y_tr), LAMBDA))
        w_star = ols_warm_start(X_tr, y_tr)
    else:
        w_star, f_star = reference_solution(X_tr, y_tr, LAMBDA)
        skl_spar_str = ", ".join(f"sp@{tol:.0e}={_sparsity(w_star, tol):.0%}"
                                 for tol in SPARSITY_TOLS)
        print(f"  f* (sklearn) = {f_star:.6f}, {skl_spar_str}, "
              f"sklearn test MSE = {_mse(y_te, X_te @ w_star):.4f}")

    w_ols = ols_warm_start(X_tr, y_tr)
    f_w0 = float(f_lasso(X_tr, y_tr, w_ols, LAMBDA))
    print(f"  f(w_0) (OLS warm start) = {f_w0:.6f}")

    res_i = irls(X_tr, y_tr, LAMBDA,
                 eps_thr=1e-8, eps_stop=1e-12,
                 k_max=IRLS_KMAX, solver="cholesky",
                 w0=w_ols, f_star=f_star)
    w_i = res_i["w"]
    f_i = f_lasso(X_tr, y_tr, w_i, LAMBDA)
    tag_i = " (matches sklearn precision)" if res_i["gaps"][-1] == 0.0 else ""
    spar_i_str = ", ".join(f"sp@{tol:.0e}={_sparsity(w_i, tol):.0%}"
                           for tol in SPARSITY_TOLS)
    print(f"  IRLS : {res_i['n_iter']} iter, "
          f"gap = {res_i['gaps'][-1]:.3e}{tag_i}, f = {f_i:.6f}, "
          f"{spar_i_str}, "
          f"test MSE = {_mse(y_te, X_te @ w_i):.4f}")

    # "As submitted" config: delta0 = c * f_star, rho = 0.9.
    res_d_old = deflected_subgradient(
        X_tr, y_tr, LAMBDA,
        w0=w_ols, i_max=DSM_IMAX, beta=1.0,
        delta0=DSM_DELTA0_OLD * f_star, rho=DSM_RHO_OLD,
        f_star=f_star,
    )
    w_d_old = res_d_old["w"]
    f_d_old = f_lasso(X_tr, y_tr, w_d_old, LAMBDA)
    spar_d_old_str = ", ".join(f"sp@{tol:.0e}={_sparsity(w_d_old, tol):.0%}"
                               for tol in SPARSITY_TOLS)
    print(f"  SGPTL (submitted, rho={DSM_RHO_OLD}, delta0=c*f*): "
          f"{res_d_old['n_iter']} iter, "
          f"record gap = {res_d_old['gaps'][-1]:.3e}, f = {f_d_old:.6f}, "
          f"{spar_d_old_str}, test MSE = {_mse(y_te, X_te @ w_d_old):.4f}")

    # Fixed config: delta0 = c * f(w_0), rho = 0.7 (motivated in Section 5.3.3).
    res_d = deflected_subgradient(
        X_tr, y_tr, LAMBDA,
        w0=w_ols, i_max=DSM_IMAX, beta=1.0,
        delta0=DSM_DELTA0 * f_w0, rho=DSM_RHO,
        f_star=f_star,
    )
    w_d = res_d["w"]
    f_d = f_lasso(X_tr, y_tr, w_d, LAMBDA)
    tag_d = " (matches sklearn precision)" if res_d["gaps"][-1] == 0.0 else ""
    spar_d_str = ", ".join(f"sp@{tol:.0e}={_sparsity(w_d, tol):.0%}"
                           for tol in SPARSITY_TOLS)
    print(f"  SGPTL (fixed,     rho={DSM_RHO}, delta0=c*f(w_0)): "
          f"{res_d['n_iter']} iter, "
          f"record gap = {res_d['gaps'][-1]:.3e}{tag_d}, f = {f_d:.6f}, "
          f"{spar_d_str}, test MSE = {_mse(y_te, X_te @ w_d):.4f}")

    # closed-form Ridge baseline at the same regularisation strength
    A_ridge = X_tr.T @ X_tr + LAMBDA * np.eye(X_tr.shape[1])
    w_ridge = solve_spd(A_ridge, X_tr.T @ y_tr, method="cholesky")
    print(f"  Ridge: closed form, test MSE = {_mse(y_te, X_te @ w_ridge):.4f}")

    return {
        "name": name,
        "M_train": M, "M_test": X_te_raw.shape[0], "d": d_in, "H": H,
        "f_star": f_star,
        "f_w0":  f_w0,
        "f_irls": f_i,
        "f_dsm":  f_d,
        "f_dsm_old": f_d_old,
        "gap_irls": res_i["gaps"][-1],
        "gap_dsm":  res_d["gaps"][-1],
        "iter_irls": res_i["n_iter"],
        "iter_dsm":  res_d["n_iter"],
        "spar_skl_1e6":  _sparsity(w_star,   1e-6),
        "spar_irls_1e6": _sparsity(w_i,      1e-6),
        "spar_dsm_1e6":  _sparsity(w_d,      1e-6),
        "spar_dsm_old_1e6": _sparsity(w_d_old, 1e-6),
        "spar_skl_1e3":  _sparsity(w_star,   1e-3),
        "spar_irls_1e3": _sparsity(w_i,      1e-3),
        "spar_dsm_1e3":  _sparsity(w_d,      1e-3),
        "spar_dsm_old_1e3": _sparsity(w_d_old, 1e-3),
        "mse_skl":     _mse(y_te, X_te @ w_star),
        "mse_irls":    _mse(y_te, X_te @ w_i),
        "mse_dsm":     _mse(y_te, X_te @ w_d),
        "mse_dsm_old": _mse(y_te, X_te @ w_d_old),
        "mse_ridge":   _mse(y_te, X_te @ w_ridge),
        "_irls_gaps":  res_i["gaps"],
        "_dsm_gaps":   res_d["gaps"],
        "_irls_fvals": res_i["f_vals"],
        "_dsm_fbar":   res_d["f_bar"],
        "_dsm_old_fbar": res_d_old["f_bar"],
    }


def run() -> None:
    print("=" * 60)
    print("Real-data experiment (ELM + LASSO)")
    print("=" * 60)

    rows = []
    for name in ("diabetes", "california"):
        try:
            rows.append(run_one(name))
        except Exception as exc:  # noqa: BLE001
            print(f"  [skip {name}: {exc}]")

    if not rows:
        print("\nNo datasets ran successfully; nothing to save.")
        return

    # CSV table — strip the per-iteration trace columns (prefix "_").
    tab_path = os.path.join(TAB_DIR, "real_data.csv")
    public_keys = [k for k in rows[0].keys() if not k.startswith("_")]
    with open(tab_path, "w", newline="") as fh:
        wr = csv.DictWriter(fh, fieldnames=public_keys)
        wr.writeheader()
        for r in rows:
            wr.writerow({k: r[k] for k in public_keys})
    print(f"\nSaved: {tab_path}")

    # gap to f_min := min{f_irls, f_dsm, f_sklearn} per dataset (IRLS and SGPTL
    # routinely beat sklearn CD at the budgeted tolerance, so f* is not always usable)
    n_panels = len(rows)
    fig, axes = plt.subplots(1, n_panels, figsize=(7.0 * n_panels, 5.5),
                             squeeze=False)
    floor = 1e-12
    for ax, row in zip(axes[0], rows):
        irls_fvals = np.asarray(row["_irls_fvals"],   dtype=float)
        dsm_fbar   = np.asarray(row["_dsm_fbar"],     dtype=float)
        dsm_old_fb = np.asarray(row["_dsm_old_fbar"], dtype=float)
        f_baseline = float(min(irls_fvals.min(), dsm_fbar.min(),
                               dsm_old_fb.min(), row["f_star"]))

        irls_gap   = np.maximum(irls_fvals - f_baseline, floor)
        dsm_gap    = np.maximum(dsm_fbar   - f_baseline, floor)
        dsm_old_gap= np.maximum(dsm_old_fb - f_baseline, floor)
        skl_gap    = max(row["f_star"] - f_baseline, floor)

        irls_iters    = np.arange(1, len(irls_gap)    + 1)
        dsm_iters     = np.arange(1, len(dsm_gap)     + 1)
        dsm_old_iters = np.arange(1, len(dsm_old_gap) + 1)

        ax.loglog(irls_iters, irls_gap,
                  color=COLOR_IRLS, marker="o", markersize=4.0,
                  linewidth=2.0, label=r"IRLS  $f(w_k) - f_{\min}$")
        ax.loglog(dsm_old_iters, dsm_old_gap,
                  color=COLOR_DSM, linestyle="--", linewidth=1.5, alpha=0.65,
                  label=r"SGPTL (submitted, $\rho{=}0.9$)")
        ax.loglog(dsm_iters, dsm_gap,
                  color=COLOR_DSM, linewidth=2.0,
                  label=r"SGPTL (fixed, $\rho{=}0.7$)")
        ax.axhline(skl_gap, color="#2c7a30", linestyle="--",
                   linewidth=1.4, alpha=0.85,
                   label=r"sklearn $f^{*}-f_{\min}$")
        ax.scatter([1], [irls_gap[0]], s=80, marker="*",
                   color="black", zorder=6,
                   label="OLS warm start (shared)")

        ax.set_xlabel("Iteration  (log scale)")
        ax.set_ylabel(r"$f - f_{\min}$  (log scale)")
        ax.set_title(f"{row['name']} ($M={row['M_train']}$, $H={row['H']}$)")
        ax.legend(loc="lower left", fontsize=10)
        ax.set_ylim(bottom=1e-10)
        style_axes(ax)
    fig.tight_layout()
    fig_path = os.path.join(FIG_DIR, "real_data_convergence.pdf")
    fig.savefig(fig_path)
    print(f"Saved: {fig_path}")
    plt.close(fig)


if __name__ == "__main__":
    run()
