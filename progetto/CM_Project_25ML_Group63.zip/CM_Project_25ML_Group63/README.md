# CM Project 25 ML — Group 63

ELM + LASSO project: two algorithms solving
`min_w  f(w) = (1/2) ||X w - y||^2 + lambda ||w||_1`
on the output layer of an Extreme Learning Machine.

- **A1 — IRLS** (Iteratively Reweighted Least Squares).
- **A2 — SGPTL** (Stepsize-restricted deflected subgradient with target level).

## Layout

```
main.pdf                              Final report.
code/
  src/
    elm.py                            Random hidden layer (fixed W_1).
    lasso_utils.py                    Objective, gradient, subgradient, KKT gap.
    linear_solvers.py                 Cholesky and Jacobi-preconditioned CG.
    irls.py                           Algorithm A1 (IRLS).
    deflected_subgradient.py          Algorithm A2 (SGPTL).
    data_generation.py                Synthetic LASSO instances + sklearn reference.
  experiments/
    experiment_convergence.py         IRLS vs SGPTL convergence on H=100, M=300.
    experiment_comparison.py          Iterations / time to reach target accuracy.
    experiment_params.py              Parameter sweeps: eps_thr, lambda, delta_0, rho.
    experiment_warm_vs_cold.py        Effect of gamma_min floor on warm/cold starts.
    experiment_scalability.py         CPU cost vs problem size, H = 50..2000.
    experiment_real_data.py           Diabetes + California housing under ELM transform.
    smoke_rho.py                      Small-budget rho sensitivity used in Section 5.3.3.
    _plot_style.py                    Shared matplotlib styling.
  tests/                              pytest suite (53 tests).
  results/
    figures/                          PDF figures used in the report.
    tables/                           CSV tables.
```

## Requirements

Python 3.10+ with `numpy`, `scipy`, `scikit-learn`, `matplotlib`, `pytest`.
The code was developed and tested against the versions shipped with a recent
SciPy stack (NumPy 1.26, SciPy 1.13, scikit-learn 1.5, Matplotlib 3.9).

## Reproducing the figures and tables

From the `code/` directory:

```
python -m experiments.experiment_convergence
python -m experiments.experiment_comparison
python -m experiments.experiment_params
python -m experiments.experiment_warm_vs_cold
python -m experiments.experiment_scalability
python -m experiments.experiment_real_data
```

Each script regenerates the PDFs in `results/figures/` and the CSVs in
`results/tables/` that are referenced in the report. Random seeds are fixed
inside each script (`SEED = 42` by default), so results are reproducible.

## Running the tests

```
pytest tests/ -q
```

53 tests, < 2 seconds. Some tests are marked `slow` (convergence over many
iterations) and can be skipped with `pytest tests/ -q -m "not slow"`.

## Notes

- All algorithmic primitives (IRLS, SGPTL, Cholesky, CG) are hand-written;
  scikit-learn's `Lasso` is used only as an external reference for the
  optimum on synthetic instances and as a baseline on real data, never as
  the implementation of either project algorithm.
- `delta_0` for SGPTL is scaled on `f(w_0)`, the value of the objective at
  the OLS warm start (an a-priori quantity), as motivated in Section 5.3.3
  of the report.
- `rho = 0.7` is the default contraction factor for SGPTL, motivated by
  literature (Brännlund 1993, Goffin-Kiwiel 1999, Bertsekas 1999) and by
  the small-budget sweep `smoke_rho.py`.
